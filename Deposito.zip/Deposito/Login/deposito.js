let vendas = [
    {
        data: "22-11-2023",
        produtos: [
            {
                nome: "Coca-Cola",
                quantidade: 2,
                valor: 5.00,
                hora: "12:00",
            },
            {
                nome: "Pepsi",
                quantidade: 1,
                valor: 4.50,
                hora: "12:00",
            },
        ]
    }
];
JSON.stringify(vendas);
console.log(vendas);